const bodyParser = require("body-parser");
const express = require("express");
const GeoPoint = require("geopoint");

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));

/* PostgreSQL and PostGIS module and connection setup */
const { Client, Query } = require("pg");
var conString =
  "postgres://wast:td!21kra@tsaw-advisory.clhj36njyzys.us-east-1.rds.amazonaws.com:5432/postgres"; //  Database Connection

const liesInsideBoundingCoordinates = (x1, y1, x2, y2, x, y) => {
  //checks whether the bounding coordinates lies within the given rectangle or not
  if (x > x1 && x < x2 && y > y1 && y < y2) return true;
  else return false;
};

const coordinateDistance = (userGeoPoint, dbGeoPoint) => {
  let distance = dbGeoPoint.distanceTo(userGeoPoint, true); // calculating distance between two geopoints
  return distance;
};

const checkingBoundingCoordinates = (userGeoPoint, dbGeoPoint, radius) => {
  let boundingCoordinates = dbGeoPoint.boundingCoordinates(radius, "", true);
  let x1 = boundingCoordinates[0]["_degLat"];
  let y1 = boundingCoordinates[0]["_degLon"];
  let x2 = boundingCoordinates[1]["_degLat"];
  let y2 = boundingCoordinates[1]["_degLon"];
  let x = userGeoPoint["_degLat"];
  let y = userGeoPoint["_degLon"];
  if (liesInsideBoundingCoordinates(x1, y1, x2, y2, x, y)) return true;
  else {
    return false;
  }
};


app.get("/", function (req, res) {
 
  //reading latitude and longitude
  let responseMessages = {}; //for storing responseMessages

  let lat = parseFloat(req.query.lat); //defining latitude
  let long = parseFloat(req.query.long); //defining longitude
  let userGeoPoint = new GeoPoint(lat, long);
  let retrieve_query =
    "select row_to_json(t) from ( select * from flying_zone) t"; // getting data from database
  var client = new Client(conString);
  client.connect(); // making connection
  var query = client.query(new Query(retrieve_query));
  query.on("row", function (row, result) {
    result.addRow(row);
  });
  query.on("end", function (result) {
    result.rows.forEach((row) => {
      let lat = parseFloat(row.row_to_json.latitude); //defining latitude
      let long = parseFloat(row.row_to_json.longitude); //defining longitude
      let radius = row.row_to_json.radius;
      let dbGeoPoint = new GeoPoint(lat, long);
      if (
        checkingBoundingCoordinates(userGeoPoint, dbGeoPoint, radius) &&
        coordinateDistance(userGeoPoint, dbGeoPoint) < radius
      ) {
        //if it lies inside the boundaries
        let advisory = {
          "requested point": [userGeoPoint["_degLat"], userGeoPoint["_degLon"]],
          "zone circle": row.row_to_json.zone_circle,
          "owner type": row.row_to_json.owner_type,
          "owner name": row.row_to_json.owner_name,
          "clearance authority": row.row_to_json.clearance_authority,
        };
        responseMessages = advisory;
      } else {
        //if it doesnt lies inside the boundaries
      }
    });
    res.header("Access-Control-Allow-Origin", "*"); //settting header for cross origin interaction
    let resJson = JSON.stringify(responseMessages);

    if (resJson === JSON.stringify({})) {
      res.status(201).json(JSON.stringify({
        "requested point": [userGeoPoint["_degLat"], userGeoPoint["_degLon"]],
        "message":"Your requested latitude and longitude doesn't lies in any zone as per our data.",
      }));
    } else {
      res.status(201).json(resJson); //sending JSON
    }
  });
});
app.listen(3000);

const csv = require('csv-parser');
const fs = require('fs');
fs.createReadStream('qw.csv')
.pipe(csv())
.on('data', (row) => {
  console.log(row);
  client.query('INSERT into flying_zone(owner_name,clearance_authority,city,state,zone_circle,owner_type,latitude,longitude,radius) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)',[row["owner_name"],row["clearance_authority"],row["city"],row["state"],row["zone_circle"],row["owner_type"],row["latitude"],row["longitude"],row["radius"]],(err,result)=>{
    if(err){
     console.log("error**********"+err);
    }
    else{
      console.log("entered");
    }
  });
})
.on('end', () => {
  console.log('CSV file successfully processed');
});
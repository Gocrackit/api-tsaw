const projectGroup = [
  {
    id: 1,
    name: "dummy",
    dateCreation: "30/07/2020",
    isActive: true,
  },
];
exports.renderDashboard = (req, res) => {
  res.render("index", {
    projectGroup: projectGroup,
    pageTitle: "Dashboard",
  });
};
exports.showProject = (req, res) => {
  if (req.query.i) {
    res.render("project", {
      projectInfo: projectGroup,
      projectName: "Dummy project name",
    });
  } else {
    res.redirect("/projects");
  }
};
exports.showProjectPhotos = (req, res) => {
  res.render("project-data-photos");
};
exports.showProjectVideos = (req, res) => {
    res.render("project-data-videos");
  };
  exports.showProjectProcessed = (req, res) => {
    res.render("project-data-processed");
  };
exports.renderProfile = (req, res) => {
  res.render("profile", {
    name: "abc",
    email: "abc@mail.com",
    pageTitle: "profile ",
    projectGroup: projectGroup,
  });
};
exports.sendProjects = (req, res) => {
  res.send("sadf power");
};

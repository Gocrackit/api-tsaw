const bodyParser=require("body-parser");
const express = require("express");
const app = express();
const errorController=require("./controllers/error");
const projectController=require("./controllers/projects");
const path = require("path");
app.set('view engine','ejs');
app.set('views','views');
app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static(path.join(__dirname,'public')));
app.use("/admin/",projectController.sendProjects);
app.use("/index",projectController.renderDashboard);
app.use("/profile",projectController.renderProfile);
app.get("/project",projectController.showProject);
app.get("/project-data-photos",projectController.showProjectPhotos);
app.get("/project-data-videos",projectController.showProjectVideos);
app.get("/project-data-processed",projectController.showProjectProcessed);


app.use(errorController.get404);
app.listen(3000)
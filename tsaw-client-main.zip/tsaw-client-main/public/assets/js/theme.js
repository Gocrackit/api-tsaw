(function ($) {
  "use strict"; // Start of use strict

  // Toggle the side navigation
  $("#sidebarToggle, #sidebarToggleTop").on("click", function (e) {
    $("body").toggleClass("sidebar-toggled");
    $(".sidebar").toggleClass("toggled");
    if ($(".sidebar").hasClass("toggled")) {
      $(".sidebar .collapse").collapse("hide");
    }
  });
  if ($(window).width() < 768) {
    $("body").toggleClass("sidebar-toggled");
    $(".sidebar").toggleClass("toggled");
    if ($(".sidebar").hasClass("toggled")) {
      $(".sidebar .collapse").collapse("hide");
    }
  }
  // Close any open menu accordions when window is resized below 768px
  $(window).resize(function () {
    if ($(window).width() < 768) {
      $("body").toggleClass("sidebar-toggled");
      $(".sidebar").toggleClass("toggled");
      if ($(".sidebar").hasClass("toggled")) {
        $(".sidebar .collapse").collapse("hide");
      }
    }
  });

  // Prevent the content wrapper from scrolling when the fixed side navigation hovered over
  $("body.fixed-nav .sidebar").on(
    "mousewheel DOMMouseScroll wheel",
    function (e) {
      if ($(window).width() > 768) {
        var e0 = e.originalEvent,
          delta = e0.wheelDelta || -e0.detail;
        this.scrollTop += (delta < 0 ? 1 : -1) * 30;
        e.preventDefault();
      }
    }
  );

  // Scroll to top button appear
  $(document).on("scroll", function () {
    var scrollDistance = $(this).scrollTop();
    if (scrollDistance > 100) {
      $(".scroll-to-top").fadeIn();
    } else {
      $(".scroll-to-top").fadeOut();
    }
  });

  // Smooth scrolling using jQuery easing
  $(document).on("click", "a.scroll-to-top", function (e) {
    var $anchor = $(this);
    $("html, body")
      .stop()
      .animate(
        {
          scrollTop: $($anchor.attr("href")).offset().top,
        },
        1000,
        "easeInOutExpo"
      );
    e.preventDefault();
  });
})(jQuery); // End of use strict

// index page js starts

// index page js end
//project page js starts
function changeView(viewType){
  if(viewType=="grid-1"){
    $("#grid-view-3").addClass("border-0").removeClass("border-dark");
    $("#grid-view-1").addClass("border-dark").removeClass("border-0");
    $(".grid-view").addClass("col-lg-12 grid-1-height").removeClass("col-lg-4");
  }
  else if(viewType =="grid-3"){
    $("#grid-view-1").addClass("border-0").removeClass("border-dark");
    $("#grid-view-3").addClass("border-dark").removeClass("border-0");
    $(".grid-view").addClass("col-lg-4 ").removeClass("col-lg-12 grid-1-height");
  }
}

$("#project-data-view-selection").on("change",function (event) {
  $("#project-page-loader").html("");
  $("#wait").fadeIn(()=>{
    let url=$("#project-data-view-selection").val();
    $("#project-page-loader").load(url,()=>{
      $("#wait").fadeOut();
    });
  });

});

//project page js ends
